﻿
using System;
namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HELLO WORLD");
        }
    }
}
